USE [hive]
EXEC sp_MSforeachtable @command1 = "DROP TABLE ?"