# The Free SQL Server Download Pack from Brent Ozar Unlimited

(C) 2018, Brent Ozar Unlimited.

To get the latest version, visit:
https://www.BrentOzar.com/first-aid/



Hi! You've just downloaded a bunch of free stuff that we hope you find useful.
It's our scripts, setup checklists, e-books, and posters about Microsoft SQL
Server. We built this stuff because we needed it too - we're Brent Ozar
Unlimited, a boutique consulting firm that focuses on making SQL Server faster
and more reliable.


The posters and books are pretty self-explanatory. The scripts are:

sp_Blitz - "Somebody just handed me a SQL Server. Is it in good shape?" 

sp_BlitzFirst - "Why is my SQL Server slow right now?"

sp_BlitzCache - "What are the most resource-intensive queries on this server?"

sp_BlitzIndex - "How could I tune indexes to make this database faster?"

sp_BlitzQueryStore - "How has this query performed over time?" 

Power BI Dashboard for DBAs - "How has my server performed over time?"

sp_AllNightLog - "How can I automate cloud log shipping even when new databases are added?"

Documentation for all of them, including parameters and results explanations: 
https://www.brentozar.com/first-aid/



Here's how to get support: https://www.brentozar.com/support

Thanks, and we hope we helped make your job suck just a little less.
The Humans of Brent Ozar Unlimited