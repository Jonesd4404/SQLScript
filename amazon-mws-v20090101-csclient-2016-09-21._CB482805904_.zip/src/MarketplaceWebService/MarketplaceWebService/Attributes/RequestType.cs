﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketplaceWebService.Attributes
{
    public enum RequestType
    {
        STREAMING,
        MIXED,
        DEFAULT,
    }
}
